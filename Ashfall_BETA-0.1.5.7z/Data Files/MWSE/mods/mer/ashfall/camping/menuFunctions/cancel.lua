return {
    text = tes3.findGMST(tes3.gmst.sCancel).value,
    requirements = function()
        return true
    end,
    callback = function() return true end,
}