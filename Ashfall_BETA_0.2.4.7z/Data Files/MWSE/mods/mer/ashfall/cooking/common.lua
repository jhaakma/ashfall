local this = {}

this.recipeType = {
    boiled = { name = "Boiled" },
    roasted = { name = "Roasted" },
    prepared = { name = "Prepared" },
    brewed = { name = "Brewed" },
}

return this